import React  from 'react';
import './UserInput.css'

const userInput=(props)=>{
    return(<input class="div_input" 
    type="text" 
    onChange={props.changed}
    value={props.defaultName}/>);
}
export default userInput;