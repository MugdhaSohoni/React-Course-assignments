import React from 'react';

import './UserOutput.css';
const userOutput=(props)=>{
    return (
        <div className="div_out">
            <p>
            {props.name} thinks of Wind and her wild ways the year we had nothing to lose and lost it anyway in the 
            cursed country of the fox. 
            </p>
            <p>
            We still talk about that winter, how the cold froze imaginary buffalo
             on the stuffed horizon of snowbanks
            </p>
        </div>
    )

}
export default userOutput;